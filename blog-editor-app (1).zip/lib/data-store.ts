// Shared in-memory data store for demo purposes
// In production, this would be replaced with a real database

interface BlogPost {
  _id: string
  title: string
  content: string
  tags: string[]
  status: "draft" | "published"
  created_at: string
  updated_at: string
}

const blogs: BlogPost[] = []
let nextId = 1

export function getBlogs(): BlogPost[] {
  return blogs
}

export function addBlog(blog: BlogPost): void {
  blogs.push(blog)
  nextId++
}

export function updateBlog(id: string, updatedBlog: BlogPost): void {
  const index = blogs.findIndex((b) => b._id === id)
  if (index !== -1) {
    blogs[index] = updatedBlog
  }
}

export function getBlogById(id: string): BlogPost | undefined {
  return blogs.find((b) => b._id === id)
}

export function getNextId(): number {
  return nextId++
}

export function deleteBlog(id: string): boolean {
  const index = blogs.findIndex((b) => b._id === id)
  if (index !== -1) {
    blogs.splice(index, 1)
    return true
  }
  return false
}
