import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sparkles, Clock, Infinity, Bot } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 bg-white/80 backdrop-blur-sm border-b">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">BC</span>
          </div>
          <div>
            <h1 className="font-bold text-xl text-gray-900">BlogCraft</h1>
            <p className="text-xs text-gray-500">AI-Powered Writing</p>
          </div>
        </div>
        <nav className="flex items-center gap-4">
          <Link href="/posts" className="text-gray-600 hover:text-gray-900">
            My Posts
          </Link>
          <Link href="/editor">
            <Button className="bg-purple-600 hover:bg-purple-700">Start Writing</Button>
          </Link>
        </nav>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-16">
        <div className="text-center max-w-4xl mx-auto">
          <Badge variant="secondary" className="mb-8 bg-purple-100 text-purple-700 border-purple-200">
            <Sparkles className="w-4 h-4 mr-2" />
            AI-Powered Auto-Save Technology
          </Badge>

          <h1 className="text-6xl font-bold mb-6">
            Igniting{" "}
            <span className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 bg-clip-text text-transparent">
              Creativity
            </span>
          </h1>

          <h2 className="text-4xl font-bold text-gray-700 mb-8">One Word at a Time</h2>

          <p className="text-lg text-gray-600 italic mb-8">"Writing is powerful when you have the right tools."</p>

          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Our platform combines <span className="font-semibold text-orange-500">AI-powered auto-save</span> to ensure
            that every writing session is both productive and uniquely tailored to meet your creative needs and
            preferences.
          </p>

          <p className="text-lg text-purple-600 mb-12">Join us in revolutionizing the way we write.</p>

          <div className="flex gap-4 justify-center mb-16">
            <Link href="/editor">
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700 px-8">
                <Sparkles className="w-5 h-5 mr-2" />
                Start Writing
              </Button>
            </Link>
            <Link href="/preview">
              <Button size="lg" variant="outline" className="px-8">
                See Preview
              </Button>
            </Link>
          </div>

          {/* Features */}
          <div className="flex justify-center gap-12 mb-16">
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-purple-600 mb-2">5s</h3>
              <p className="text-gray-600">Auto-Save</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Infinity className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-purple-600 mb-2">∞</h3>
              <p className="text-gray-600">Drafts</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bot className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-purple-600 mb-2">AI</h3>
              <p className="text-gray-600">Powered</p>
            </div>
          </div>
        </div>

        {/* Why Choose Us Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Why Choose Us</h2>
          <h3 className="text-4xl font-bold mb-8">
            Welcome to{" "}
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              BlogCraft
            </span>
          </h3>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Experience the future of writing with our intelligent platform designed for creators.
          </p>
        </div>
      </main>
    </div>
  )
}
