import { NextResponse } from "next/server"
import { getBlogs, addBlog, updateBlog, getNextId } from "../../../../lib/data-store"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { _id, title, content, tags } = body

    const now = new Date().toISOString()

    if (_id) {
      // Update existing draft
      const blogs = getBlogs()
      const existingBlog = blogs.find((b) => b._id === _id)
      if (existingBlog) {
        const updatedBlog = {
          ...existingBlog,
          title: title || "",
          content: content || "",
          tags: tags || [],
          status: "draft" as const,
          updated_at: now,
        }
        updateBlog(_id, updatedBlog)
        return NextResponse.json(updatedBlog)
      }
    }

    // Create new draft
    const newBlog = {
      _id: getNextId().toString(),
      title: title || "",
      content: content || "",
      tags: tags || [],
      status: "draft" as const,
      created_at: now,
      updated_at: now,
    }

    addBlog(newBlog)

    return NextResponse.json(newBlog)
  } catch (error) {
    console.error("Error saving draft:", error)
    return NextResponse.json({ error: "Failed to save draft" }, { status: 500 })
  }
}
