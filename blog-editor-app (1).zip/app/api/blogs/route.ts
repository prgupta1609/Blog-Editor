import { NextResponse } from "next/server"
import { getBlogs } from "../../../lib/data-store"

export async function GET() {
  try {
    const blogs = getBlogs()
    // Sort by updated_at descending (newest first)
    const sortedBlogs = blogs.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
    return NextResponse.json(sortedBlogs)
  } catch (error) {
    console.error("Error fetching blogs:", error)
    return NextResponse.json({ error: "Failed to fetch blogs" }, { status: 500 })
  }
}
