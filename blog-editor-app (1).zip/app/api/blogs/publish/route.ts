import { NextResponse } from "next/server"
import { getBlogs, addBlog, updateBlog, getNextId } from "../../../../lib/data-store"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { _id, title, content, tags } = body

    // Validation
    if (!title?.trim() || !content?.trim()) {
      return NextResponse.json({ error: "Title and content are required for publishing" }, { status: 400 })
    }

    const now = new Date().toISOString()

    if (_id) {
      // Update existing post and publish
      const blogs = getBlogs()
      const existingBlog = blogs.find((b) => b._id === _id)
      if (existingBlog) {
        const updatedBlog = {
          ...existingBlog,
          title,
          content,
          tags: tags || [],
          status: "published" as const,
          updated_at: now,
        }
        updateBlog(_id, updatedBlog)
        return NextResponse.json(updatedBlog)
      }
    }

    // Create new published post
    const newBlog = {
      _id: getNextId().toString(),
      title,
      content,
      tags: tags || [],
      status: "published" as const,
      created_at: now,
      updated_at: now,
    }

    addBlog(newBlog)

    return NextResponse.json(newBlog)
  } catch (error) {
    console.error("Error publishing blog:", error)
    return NextResponse.json({ error: "Failed to publish blog" }, { status: 500 })
  }
}
