"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Save, Send, Clock, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"

interface BlogPost {
  _id?: string
  title: string
  content: string
  tags: string[]
  status: "draft" | "published"
  created_at?: string
  updated_at?: string
}

export default function EditorPage() {
  const [post, setPost] = useState<BlogPost>({
    title: "",
    content: "",
    tags: [],
    status: "draft",
  })
  const [tagsInput, setTagsInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [lastSaved, setLastSaved] = useState<Date | null>(null)
  const [isAutoSaving, setIsAutoSaving] = useState(false)

  const { toast } = useToast()
  const router = useRouter()
  const searchParams = useSearchParams()
  const editId = searchParams.get("id")

  // Load existing post if editing
  useEffect(() => {
    if (editId) {
      loadPost(editId)
    }
  }, [editId])

  const loadPost = async (id: string) => {
    try {
      const response = await fetch(`/api/blogs/${id}`)
      if (response.ok) {
        const data = await response.json()
        setPost(data)
        setTagsInput(data.tags.join(", "))
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load post",
        variant: "destructive",
      })
    }
  }

  // Debounced auto-save function
  const debouncedAutoSave = useCallback(
    debounce(async (postData: BlogPost) => {
      if (!postData.title.trim() && !postData.content.trim()) return

      setIsAutoSaving(true)
      try {
        const response = await fetch("/api/blogs/save-draft", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(postData),
        })

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }

        const contentType = response.headers.get("content-type")
        if (!contentType || !contentType.includes("application/json")) {
          throw new Error("Response is not JSON")
        }

        const savedPost = await response.json()
        setPost((prev) => ({ ...prev, _id: savedPost._id }))
        setLastSaved(new Date())
        toast({
          title: "Auto-saved",
          description: "Your changes have been automatically saved",
          duration: 2000,
        })
      } catch (error) {
        console.error("Auto-save failed:", error)
        // Don't show error toast for auto-save failures to avoid annoying the user
      } finally {
        setIsAutoSaving(false)
      }
    }, 5000),
    [],
  )

  // Auto-save when content changes
  useEffect(() => {
    const postWithTags = {
      ...post,
      tags: tagsInput
        .split(",")
        .map((tag) => tag.trim())
        .filter((tag) => tag),
    }
    debouncedAutoSave(postWithTags)
  }, [post.title, post.content, tagsInput, debouncedAutoSave, post])

  const handleSaveDraft = async () => {
    setIsLoading(true)
    try {
      const postData = {
        ...post,
        tags: tagsInput
          .split(",")
          .map((tag) => tag.trim())
          .filter((tag) => tag),
      }

      const response = await fetch("/api/blogs/save-draft", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(postData),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const savedPost = await response.json()
      setPost(savedPost)
      setLastSaved(new Date())
      toast({
        title: "Draft saved",
        description: "Your draft has been saved successfully",
      })
    } catch (error) {
      console.error("Save draft error:", error)
      toast({
        title: "Error",
        description: "Failed to save draft. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handlePublish = async () => {
    if (!post.title.trim() || !post.content.trim()) {
      toast({
        title: "Validation Error",
        description: "Title and content are required for publishing",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const postData = {
        ...post,
        tags: tagsInput
          .split(",")
          .map((tag) => tag.trim())
          .filter((tag) => tag),
      }

      const response = await fetch("/api/blogs/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(postData),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()
      toast({
        title: "Published!",
        description: "Your post has been published successfully",
      })
      router.push("/posts")
    } catch (error) {
      console.error("Publish error:", error)
      toast({
        title: "Error",
        description: "Failed to publish post. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b px-6 py-4">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-purple-600 rounded flex items-center justify-center">
                <span className="text-white font-bold text-xs">BC</span>
              </div>
              <span className="font-semibold">BlogCraft Editor</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {lastSaved && (
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Clock className="w-4 h-4" />
                Last saved: {lastSaved.toLocaleTimeString()}
              </div>
            )}
            {isAutoSaving && (
              <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                Auto-saving...
              </Badge>
            )}
            <Button variant="outline" onClick={handleSaveDraft} disabled={isLoading}>
              <Save className="w-4 h-4 mr-2" />
              Save Draft
            </Button>
            <Button onClick={handlePublish} disabled={isLoading} className="bg-purple-600 hover:bg-purple-700">
              <Send className="w-4 h-4 mr-2" />
              Publish
            </Button>
          </div>
        </div>
      </header>

      {/* Editor */}
      <main className="max-w-4xl mx-auto px-6 py-8">
        <div className="bg-white rounded-lg shadow-sm border p-8">
          <div className="space-y-6">
            <div>
              <Input
                placeholder="Enter your blog title..."
                value={post.title}
                onChange={(e) => setPost((prev) => ({ ...prev, title: e.target.value }))}
                className="text-2xl font-bold border-none px-0 focus-visible:ring-0 placeholder:text-gray-400"
              />
            </div>

            <div>
              <Input
                placeholder="Tags (comma-separated)"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                className="border-none px-0 focus-visible:ring-0 placeholder:text-gray-400"
              />
            </div>

            <div>
              <Textarea
                placeholder="Start writing your blog content..."
                value={post.content}
                onChange={(e) => setPost((prev) => ({ ...prev, content: e.target.value }))}
                className="min-h-[500px] border-none px-0 focus-visible:ring-0 resize-none placeholder:text-gray-400 text-lg leading-relaxed"
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

// Debounce utility function
function debounce<T extends (...args: any[]) => any>(func: T, wait: number): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}
